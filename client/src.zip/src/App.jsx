
import './App.css'
import { FandAndLogo } from './components/FandAndLogo'
import { FAQ } from './components/Faq'
import { Footer } from './components/Footer'
import { RoadMap } from './components/RoadMap'

import { TokenNomics } from "./components/TokenNomics"

function App() {
  

  return (
    <>
    {/* bg-[#0a0a0a] */}
    <div className="w-[1512px] h-auto bg-[#0a0a0a] ">
     <TokenNomics/>
     <RoadMap/>
     <FandAndLogo/>
     <Footer/>
    </div>
    </>
  )
}

export default App
